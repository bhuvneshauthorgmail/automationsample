﻿namespace DatabaseCode.Tests.Support
{
    public class DriverPersonState
    {
        public Person StoredPerson { get; set; }
    }
}
