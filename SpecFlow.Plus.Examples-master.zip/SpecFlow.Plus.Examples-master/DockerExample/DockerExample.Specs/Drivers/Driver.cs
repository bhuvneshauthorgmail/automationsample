using System;

namespace DockerExample.Specs.Drivers
{
    public class Driver
    {
        
        public void CreateBackground() 
        {
        }

        public void ExecuteAction() 
        {
            
        }

        public void CheckCondition() 
        {
            
        }

    }
}
