using System;
using TechTalk.SpecFlow;

namespace DockerExample.Specs.Hooks
{
    [Binding]
    public class Hooks
    {
        
    }
}