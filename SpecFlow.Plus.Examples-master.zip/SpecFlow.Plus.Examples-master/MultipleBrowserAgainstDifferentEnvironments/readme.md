# Using Multiple Browser to test multiple Environments with Selenium

This is a example how to use SpecFlow and SpecFlow+Runner to run Selenium Web Tests for different Browsers and different environments.

## Important parts

### Default.srprofile

#### Targets

3 Targets are defined here, one for each browser/environment combination. 

