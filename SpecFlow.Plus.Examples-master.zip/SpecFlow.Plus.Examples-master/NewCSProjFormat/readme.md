# NewCsprojFormat example project

This project is based on the Getting Started example from [https://specflow.org/getting-started/](https://specflow.org/getting-started/).
But instead of using a project file in the old project format, it is built using the new Csproj format.
