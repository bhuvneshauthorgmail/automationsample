# Windows App Driver Example

This is a example how to use SpecFlow and SpecFlow+Runner to run Windows App Tests with WinAppDriver

## Important

In order for this project to work [WinAppDriver](https://github.com/Microsoft/WinAppDriver/releases) must be installed on the system and path set in app.config.
